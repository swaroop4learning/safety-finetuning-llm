import json

# Specify the path to your JSON file
json_file_path = "train.json"

# Open and read the JSON file
with open(json_file_path, 'r') as file:
    data = json.load(file)

with open("ft_datasets/dpo_dataset/train.json", 'w') as f:
    json.dump(data, f, indent=4)
