import os
import json
import torch
from torch.utils.data import Dataset

class DPOTrainDataset(Dataset):
    def __init__(self, dataset_path, tokenizer):
        self.tokenizer = tokenizer
        with open(dataset_path, 'r') as file:
            self.data = json.load(file)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        example = self.data[index]
        
        prompt = example["prompt"]
        chosen = example["chosen"]
        rejected = example["rejected"]
        
        prompt_tokens = self.tokenizer.encode(prompt)
        chosen_tokens = self.tokenizer.encode(chosen)
        rejected_tokens = self.tokenizer.encode(rejected)
        
        return {
            "prompt_ids": torch.tensor(prompt_tokens, dtype=torch.long),
            "chosen_ids": torch.tensor(chosen_tokens, dtype=torch.long),
            "rejected_ids": torch.tensor(rejected_tokens, dtype=torch.long),
        }

def get_dpo_dataset(dataset_path, tokenizer):
    return DPOTrainDataset(dataset_path, tokenizer)
